README: Definition Extraction
Sonya Anopa

The definition_extraction.py file takes in words and their definitions and produces
output in the form of Scone function calls that add the extracted knowledge.
The output requires some additional Lisp functions that are stored in
definition_extraction.lisp, therefore when trying to load the resulting knowledge
into Scone those functions should be included. The syntax for running the file is:

python definition_extraction.py word definition

where word and definition are strings (that is, there should be two arguments
to the script).

If definition_extraction.lisp is loaded into Scone the output can be put into Scone.

Requirements:
The script needs a version of Python of 2.7 and Java 8.
It also needs the following packages: nltk and pattern.
Finally, the script needs access to the folder where Stanford CoreNLP utilities
are located. With the current (2016-05-06) NLTK version, the version of Stanford
CoreNLP needs to be 3.5.2. The script assumes the CoreNLP files to be located in
a folder called "stanford-corenlp" located in the same directory as the script.
This can be modified on lines 49 and 50.