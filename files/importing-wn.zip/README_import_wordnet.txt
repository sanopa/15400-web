README: Importing WordNet
Sonya Anopa

The import_wordnet.py file is specific to importing the noun data from WordNet
into Scone. It takes in the file that the output (Lisp/Scone code) should be written
into. The output requires some additional Lisp functions that are stored in
wordnet-concepts-sanopa.lisp, therefore using that file as the output file is
recommended. The syntax for running the file is:

python import_wordnet.py file_name

If file_name is wordnet-concepts-sanopa.lisp, that file can then be directly
loaded into Scone with load-kb.

Requirements:
The script needs a version of Python of 2.7 and Java 8.
It also needs the following packages: nltk and pattern. Additionally, nltk
requires WordNet to have been downloaded (through the command nltk.download()).
Finally, the script needs access to the folder where Stanford CoreNLP utilities
are located. With the current (2016-05-06) NLTK version, the version of Stanford
CoreNLP needs to be 3.5.2. The script assumes the CoreNLP files to be located in
a folder called "stanford-corenlp" located in the same directory as the script.
This can be modified on lines 49 and 50.